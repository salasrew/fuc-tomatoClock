//
//  homeView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI

struct homeView: View {
    var body: some View {
        
        VStack
        {
            ZStack
            {
                Circle()
                    .stroke(Color(.systemGray6),lineWidth: 10)
                    .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
                Circle()
                    .foregroundColor(.white)
                    .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .overlay(
                        VStack
                        {
                            Text("30:00")
                                .font(.system(size:60,design:.rounded))
                                .foregroundColor(Color(.systemRed))

                        }

                    )
            }
            
            Text("Start")
                .font(.system(size:40,design:.rounded))
                .foregroundColor(Color(.systemRed))
        }
        
        
    }
}

struct homeView_Previews: PreviewProvider {
    static var previews: some View {
        homeView()
    }
}
