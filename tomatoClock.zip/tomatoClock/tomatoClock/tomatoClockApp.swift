//
//  tomatoClockApp.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI

@main
struct tomatoClockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

