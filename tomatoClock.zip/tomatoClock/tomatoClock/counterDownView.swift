//
//  counterDownView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI


struct counterDownView: View {
    

    var body: some View {
        

        VStack
        {
            Text("00:00") // it show timer countering down
                .font(.system(size: 80))
            
            HStack
            {
                Text("Pause")
                
                Text("Cancel")
                
                Text("Finish")
             
            }
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                Text("倒數測試")
            })
            
            
        }
    }
}

struct counterDownView_Previews: PreviewProvider {
    static var previews: some View {
        counterDownView()
    }
}

