//
//  ContentView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI

struct ContentView: View {
    @State public var timeRemaining = 10

    var body: some View {
        
        let timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
        let clock = secondsToHoursMinutesSeconds(timeRemaining)
        
        VStack
        {
            VStack {
                Text(convert(num: clock.1)+" : " + convert(num: clock.2))
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 5)
                    .background(
                        Capsule()
                            .fill(Color.black)
                            .opacity(0.75)
                    )
        }
        .onReceive(timer, perform: { _ in
            if self.timeRemaining > 0
            {
                self.timeRemaining -= 1
            }
        })
        
//        homeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
}

func secondsToHoursMinutesSeconds(_ seconds: Int) -> (Int, Int, Int) {
    let sec = (seconds % 3600) % 60
    let min = (seconds % 3600) / 60
    let hr = seconds / 3600
    
    return ( hr , min  , sec)
}

func convert(num: Int) -> String
{
    if num < 10
    {
        return "0\(num)"
    }
    return "\(num)"
}
