//
//  tomatoHowToDo.swift
//  tomatoClock
//
//  Created by USER on 2022/8/12.
//

import SwiftUI


// Show how to do 
struct tomatoHowToDoView: View {
    var body: some View {
    ZStack
    {
        Color("bgTomatoColor")
              .ignoresSafeArea()


        VStack
        {
            
            Group
            {

                Text("決定需要先完成的任務。")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)

                Text("設定番茄工作法定時器至 n 分鐘（通常為25分鐘）。")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)

                Text("持續工作直至定時器提示，記下一個番茄。")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)

                Text("短暫休息3-5分鐘。")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)

                Text("每四個番茄，休息15-30分。")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)

            }
            .foregroundColor(.white)
            .multilineTextAlignment(.center)
        }


    }
        
        

 
    }
    
}


// #FF5959

struct tomatoHowToDoView_Previews: PreviewProvider {
    static var previews: some View {
        tomatoHowToDoView()
    }
}
