//
//  ContentView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI

extension AnyTransition
{
    static var moveTrailing: AnyTransition
    {
        AnyTransition.move(edge: .trailing)
    }
    
    static var moveAndFade: AnyTransition
    {
        let insertion = AnyTransition.move(edge: .trailing)
            .combined(with: opacity)
        let removal = AnyTransition.scale
            .combined(with: opacity)

        return .asymmetric(insertion: insertion, removal: removal)
    }
}

struct ContentView: View {
    @EnvironmentObject var countdownremain: countdownRemain
    
    var body: some View {
        
        ZStack
        {

            Color("bgTomatoColor")
                    .ignoresSafeArea()
            
            if countdownremain.isActive
            {
                counterDownView().environmentObject(countdownremain)
            }
            else
            {
                homeView().environmentObject(countdownremain)
            }
    

//            counterDownView().environmentObject(countdownremain)
        }
    }
    
}

public func secondsToHoursMinutesSeconds(_ seconds: Int) -> (Int, Int, Int) {
    let sec = (seconds % 3600) % 60
    let min = (seconds % 3600) / 60
    let hr = seconds / 3600
    
    return ( hr , min  , sec)
}

public func convert(num: Int) -> String
{
    if num < 10
    {
        return "0\(num)"
    }
    return "\(num)"
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(countdownRemain())
    }
}
