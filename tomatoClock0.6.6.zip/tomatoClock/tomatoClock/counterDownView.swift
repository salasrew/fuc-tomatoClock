//
//  counterDownView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI


// This view is Timer Begin and counting down
struct counterDownView: View {
    
    @EnvironmentObject var countdownremain: countdownRemain

    func getTime() -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        let dateString = formatter.string(from: Date())
        return dateString
    }
    
    var body: some View {
        
        let timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
        
        let remainClock = secondsToHoursMinutesSeconds(countdownremain.timeRemaining)
        let times = getTime()
        

        VStack
        {

            HStack
            {
                Text("現在時間：\(times)")
//                Text(Date(), style: .time)
            }
                        
            ZStack
            {
                Text(convert(num: remainClock.1)+" : " + convert(num: remainClock.2)) // it show timer countering down
                    .font(.system(size: 80))
            

            }
            HStack
            {
                Text("預計完成時間：")
            }
            
            HStack
            {
                
                Button(action: {
                    countdownremain.isActive = false
                    countdownremain.isPause = true
                }, label: {
                    Text("Cancel")
                })
                
                Button(action: {
                    
                    if countdownremain.isPause
                    {
                        countdownremain.isPause = false
                    }
                    else
                    {
                        countdownremain.isPause = true
                    }
                
                }, label: {
                    Text("Pause")
                })
                
                // 暫時想不到解決辦法
                Button(action: {
                    countdownremain.isActive = false
                    countdownremain.isPause = true
                    
                    countdownremain.timeLast += countdownremain.timeAdd

                }, label: {
                    Text("Finish")
                })
             
            }
            // 時間到 繼續使用
            // 時間到 鈴聲和震動
            Text("累計時間\(countdownremain.timeLast)")
            Text("額外學習\(countdownremain.timeAdd)")

//            if !countdownremain.isFinish
//            {
//                Text("Time to QK")
//
//            }

            
            // 彈窗顯示
            if countdownremain.timeRemaining == 0
            {
                Text("Time to QK")

            }
            
            
            
            
        }
        .onReceive(timer, perform: { time in
            
            // 控制timer 不會自己直接執行
            guard countdownremain.isActive else { return }
            
            if !countdownremain.isPause
            {
                if countdownremain.timeRemaining > 0
                {
                    countdownremain.timeRemaining -= 1
                    countdownremain.timeLast += 1
                }
                // 如果時間到了 仍持續運作
                else
                {
                    countdownremain.timeAdd += 1
                }
            }
            countdownremain.isFinish = true

        }
        )

    }

}

struct counterDownView_Previews: PreviewProvider {
    static var previews: some View {
        counterDownView().environmentObject(countdownRemain())

    }
}


private struct GroundReflectionViewModifier: ViewModifier {
    let offsetY: CGFloat
    func body(content: Content) -> some View {
        content
            .background(
                content
                    .mask(
                        LinearGradient(
                            gradient: Gradient(stops: [.init(color: .white, location: 0.0), .init(color: .clear, location: 0.6)]),
                            startPoint: .bottom,
                            endPoint: .top)
                    )
                    .scaleEffect(x: 1.0, y: -1.0, anchor: .bottom)
                    .opacity(0.3)
                    .offset(y: offsetY)
            )
    }
}

extension View {
    func reflection(offsetY: CGFloat = 1) -> some View {
        modifier(GroundReflectionViewModifier(offsetY: offsetY))
    }
}
//
//struct GroundReflectionViewModifier_Previews: PreviewProvider {
//    static var previews: some View {
//        HStack {
//            Text("test")
//                .reflection()
//        }
//    }
//}
