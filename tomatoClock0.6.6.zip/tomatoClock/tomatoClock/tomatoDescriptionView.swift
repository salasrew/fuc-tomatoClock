//
//  tomatoDescriptionView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/12.
//

import SwiftUI


// 認識番茄工作法歷史
struct tomatoDescriptionView: View {
    
    @State  var presentationMode = false
    
    var body: some View {
        VStack
        {
            Text("番茄工作法")
                .fontWeight(.bold)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                .lineSpacing(/*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
                .padding()
            
            Text("是一種時間管理方法，在1980年代由Francesco Cirillo創立。 該方法使用一個定時器來分割出一個一般為25分鐘的工作時間和5分鐘的休息時間，而那些時間段被稱為pomodoros，為義大利語單詞 pomodoro（中文：番茄）之複數。")
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .lineSpacing(/*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
                .padding()
        
 
        
        
        }
//        .overlay(
//
//            HStack
//            {
//                Spacer()
//                VStack
//                {
//                    Button(action: {
//                        self.presentationMode.wrappedValue.dismiss()
//                    }, label: {
//                        Image(systemName: "chevron.down.circle.fill")
//                            .font(.largeTitle)
//                            .foregroundColor(.blue)
//
//
//                    })
//                    .padding(.trailing, 20)
//                    .padding(.top, 40)
//
//                    Spacer()
//                }
//
//
//            }
//        )
    }
}

struct tomatoDescriptionView_Previews: PreviewProvider {
    static var previews: some View {
        tomatoDescriptionView()
    }
}




