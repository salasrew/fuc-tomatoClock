//
//  tomatoClockApp.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI

@main
struct tomatoClockApp: App {
    
    var countdownremain = countdownRemain()
//    @EnvironmentObject var countdownremain: countdownRemain

    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(countdownremain)
//            toDoListView().environmentObject(countdownremain)
        }
    }
}

