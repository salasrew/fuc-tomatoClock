//
//  homeView.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import SwiftUI



// This page is for setting timer
struct homeView: View {
    @EnvironmentObject var countdownremain: countdownRemain
    //    @State private var showCounterDownView = false
    
    var body: some View {
        
        let clock = secondsToHoursMinutesSeconds(countdownremain.timeSetted)
        
        // 現在時間 結束時間
        
        
        ZStack
        {
            Color("bgTomatoColor")
                .ignoresSafeArea()
            
            
            
            // or we can use datepicker
            VStack
            {
                ZStack
                {
                    
                    Circle()
                        .stroke(Color(.white),lineWidth: 5)
                        .frame(width: 250, height: 250, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .overlay(
                            HStack
                            {
                                // action 原計畫用成函數
                                Button(action: {
                                    if !countdownremain.isActive
                                    {
                                        countdownremain.timeSetted -= 300
                                        if countdownremain.timeSetted < 0
                                        {
                                            countdownremain.timeSetted = 0
                                        }
                                    }
                                    
                                }, label: {
                                    Text("<")
                                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                    
                                })
                                
                                Text(convert(num: clock.1)+" : " + convert(num: clock.2))
                                    .font(.system(size:60,design:.rounded))
                                    .foregroundColor(Color(.white))
                                
                                // action 原計畫用成函數
                                Button(action: {
                                    if !countdownremain.isActive
                                    {
                                        countdownremain.timeSetted += 300
                                    }
                                }, label: {
                                    Text(">")
                                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                                })
                            }
                        )
                }
                Text("")
                Text("")
                // 按了換頁
                Button(action: {
                    
                    // 如果沒有設定時間,無動作
                    if countdownremain.timeSetted > 0
                    {
                        countdownremain.timeRemaining = countdownremain.timeSetted
                        countdownremain.isActive = true
                        countdownremain.isPause = false
                        
                    }
                }
                
                , label: {
                    Text("Start")
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .padding()

                        .cornerRadius(40)
                        .foregroundColor(.white)
                        .padding(0)
                        .overlay(
                            RoundedRectangle(cornerRadius:40)
                                .stroke(Color.white,lineWidth: 5)
                        )
                    //                #2828FF
                    //                #2894FF
                }
                )

            }
        }

        
        
    }
}

struct homeView_Previews: PreviewProvider {
    static var previews: some View {
        homeView().environmentObject(countdownRemain())
    }
}

