//
//  transitionTest.swift
//  tomatoClock
//
//  Created by USER on 2022/8/10.
//

import SwiftUI

struct transitionTest: View {
    @State private var show = false
    
    var body: some View {
        VStack
        {
            RoundedRectangle(cornerRadius: 10)
                .frame(width: 300, height: 300, alignment: .center)
                .foregroundColor(.green)
                .overlay(
                    Text("Show Details")
                        .font(.system(.largeTitle,design: .rounded))
                        .bold()
                        .foregroundColor(.white)
                    
                )
                .onTapGesture{
                    withAnimation(Animation.spring())
                    {
                        self.show.toggle()
                    }
                }
            
            
            
            
            
            
            if show{
                
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 300, height: 300, alignment: .center)
                    .foregroundColor(.purple)
                    .overlay(
                        Text("Well, here is the detail")
                            .font(.system(.largeTitle,design: .rounded))
                            .bold()
                            .foregroundColor(.white)
                        
                    )
            }
            
            
            
        }
        
        
        
    }
}

struct transitionTest_Previews: PreviewProvider {
    static var previews: some View {
        transitionTest()
    }
}
