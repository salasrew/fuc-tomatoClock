//
//  countdownRemain.swift
//  tomatoClock
//
//  Created by USER on 2022/8/9.
//

import Foundation
import Combine

final class countdownRemain : ObservableObject
{
    // time setted
    @Published var timeSetted: Int = 1500
//    @Published var timeSetted: Int = 10

    // time remain
    @Published var timeRemaining: Int = 0
    
    // time 持續
    @Published var timeLast: Int = 0
    
    // 超過時間後 加上時間
    @Published var timeAdd: Int = 0
    
    // 休息時間
    @Published var timeQK: Int = 300

    // 計時器運作
    @Published var isActive: Bool = false
    // 計時器暫停
    @Published var isPause: Bool = false
    
    // 工作完成
    @Published var isFinish: Bool = false

    // View's Boolean
    @Published var viewHomeView: Bool = true
    @Published var viewCountDownView: Bool = false
    @Published var viewHowToDoView: Bool = false
    @Published var viewSettingView: Bool = false

    
    
    
    
//    @Published var items: String
//    {
//        didSet
//        {
//            UserDefaults.standard.set(items,forKey: "items")
//        }
//    }
//    init() {
//        self.items = UserDefaults.standard.object(forKey: "items") as? String ?? ""
//    }
//
    
}

