//
//  toDoList.swift
//  tomatoClock
//
//  Created by USER on 2022/8/11.
//

import SwiftUI

struct toDoListView: View {
    @State var todolist = [ toDo(name: "Clean room", image: "aaa"),
                            toDo(name: "Read Book", image: "bb"),
                            toDo(name: "Swim", image: "bb"),
                            toDo(name: "Eat Lunch", image: "bb"),
                            toDo(name: "Meeting with senpai", image: "bb")
                            
                            
    ]
    
    @State var name = ""
    @State var image = ""

    @State var timeSpend = ""
    @State var showAddItem = true
    @State var itemAdded = true

    
    //    Image(systemName: "trash")
    
    let formatter: NumberFormatter =
        {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            return formatter
        }()
    
    var body: some View {
        
        
        //        var todo = ["Clean room","Read Book","Swim"]

        VStack
        {
            Text("To DoList")
                .bold()
            
            List
            {
                ForEach(todolist) { todoo in
                    BasicImageRow(todos : todoo)
                        .contextMenu(/*@START_MENU_TOKEN@*/ContextMenu(menuItems: {
                            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                                HStack{
                                    Text("Priority")
                                    Image(systemName: "star")
                                }
                            })
//                            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
//                                HStack{
//                                    Text("Delete")
//                                    Image(systemName: "trash")
//                                }
//                            })
                            

                        })/*@END_MENU_TOKEN@*/)
                }
                // 滑動刪除
                .onDelete(perform: { indexSet in
                    self.todolist.remove(atOffsets: indexSet)
                })
            }
            VStack(spacing: 5)
            {
                TextField("Item name",text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                TextField("預計花費時間",text: $timeSpend)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                
            }
            .isHidden(showAddItem)
            
            
            HStack
            {
                // Button Add Item
                Button(action: {
                    withAnimation{
                        add(name: name, image: image , timeSpend: timeSpend)
                        }
                    self.showAddItem.toggle()
                    self.itemAdded.toggle()
             
                   
    //                self.add(name: "Test",image:"Test")
    //                self.add(name: "",image:"")

                }, label: {
                    Text("Add Item")
                })
                

            }

            
        }

    }
    
//    private func delete(item toDo: toDo)
//    {
//        if let index = self.todolist.firstIndex(where: {$0.id == toDo.id})
//        {
//            self.todolist.remove(at: index)
//        }
//    }
    
//    private func add(item toDos: toDo)
    private func add(name: String , image: String , timeSpend: String)
    
    {   var time = timeSpend
        if name == ""
        {
            return
        }
        
        if time == "" {
            time = "0"
        }

        todolist.append(toDo(name: name,image:image,timeSpend:time))
        self.name = ""
    }
    
//    private func setPriority(item toDo: toDo)
//    {
//        if let index = self.todolist.firstIndex(where: {$0.id == toDo.id})
//        {
//            self.todolist[index].level = "Level High"
//        }
//    }
}


struct toDoListView_Previews: PreviewProvider {
    static var previews: some View {
        toDoListView()
    }
}




struct toDo: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var timeSpend: String?
    var level = ["Level High","Level medium","Level Low"]
//    var level: String


}

struct BasicImageRow: View {
    var todos: toDo
    
    var body: some View {
        HStack {
            Image(todos.image)
                .resizable()
                .frame(width: 40, height: 40)
                .cornerRadius(5)
            Text(todos.name)
            
            HStack
            {
                Spacer()
                Text("\(todos.timeSpend ?? "0")min")
                    .multilineTextAlignment(.leading)
            }

        }
    }
}

// 設定事件優先權
//private func setLevel(item todoo: toDo)
//{
//    if let index = self.
//}



extension View {
    /// Hide or show the view based on a boolean value.
    ///
    /// Example for visibility:
    ///
    ///     Text("Label")
    ///         .isHidden(true)
    ///
    /// Example for complete removal:
    ///
    ///     Text("Label")
    ///         .isHidden(true, remove: true)
    ///
    /// - Parameters:
    ///   - hidden: Set to `false` to show the view. Set to `true` to hide the view.
    ///   - remove: Boolean value indicating whether or not to remove the view.
    @ViewBuilder func isHidden(_ hidden: Bool, remove: Bool = false) -> some View {
        if hidden {
            if !remove {
                self.hidden()
            }
        } else {
            self
        }
    }
}
